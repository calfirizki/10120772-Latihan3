package com.example.a10120772latihan3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class WarningDialogActivity extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_warning_dialog);
    }
}
// Nama                 : Mochamad Aqshal Firizki
// NIM                  : 10120772
// Kelas                : IF-9
// Tanggal Pengerjaan   : 29-04-2023

